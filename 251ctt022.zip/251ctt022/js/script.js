function showAlert(message) {
  alert(message);
}

function showProductDetail(name, price, description) {
  document.getElementById("modal-title").innerText = name;
  document.getElementById("modal-price").innerText = price;
  document.getElementById("modal-desc").innerText = description;

  document.getElementById("product-detail-modal").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("product-detail-modal").classList.add("hidden");
}

const themeToggleBtn = document.getElementById("theme-toggle");
themeToggleBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");

  if (document.body.classList.contains("dark-mode")) {
    themeToggleBtn.innerText = "Giao diện sáng";
  } else {
    themeToggleBtn.innerText = "Đổi màu giao diện";
  }
});

window.onclick = function (event) {
  const modal = document.getElementById("product-detail-modal");
  if (event.target == modal) {
    modal.classList.add("hidden");
  }
};
